package org.eclipse.wb.swt;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.SWT;
//import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.DecimalFormat;

public class NileStore {

	protected Shell shlNileDotCom;
	private Text itemID;
	private Text itemQuantity;
	private Text itemDetails;
	private Text orderSubtotal;
	private int order_count;
	private Scanner file_reader;
	private ArrayList<ArrayList<String>> user_orders;
	private String ord_list;
	private DecimalFormat df = new DecimalFormat("###.##");
	public static boolean orderCompleted = false;
	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			NileStore window = new NileStore();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlNileDotCom.open();
		while (!shlNileDotCom.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		
		order_count = 0;
		user_orders = new ArrayList<ArrayList<String>>();
		shlNileDotCom = new Shell();
		shlNileDotCom.setBackground(SWTResourceManager.getColor(43, 43, 43));
		shlNileDotCom.setSize(860, 445);
		shlNileDotCom.setText("Nile Dot Com - Spring 2023");
		
		itemID = new Text(shlNileDotCom, SWT.NONE);
		itemID.setBackground(SWTResourceManager.getColor(255, 255, 255));
		itemID.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		itemID.setBounds(404, 44, 364, 37);
		itemID.setEditable(true);
		
		itemQuantity = new Text(shlNileDotCom, SWT.NONE);
		itemQuantity.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		itemQuantity.setBackground(SWTResourceManager.getColor(255, 255, 255));
		itemQuantity.setBounds(404, 87, 364, 37);
		itemQuantity.setEditable(true);
		
		itemDetails = new Text(shlNileDotCom, SWT.NONE);
		itemDetails.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		itemDetails.setBackground(SWTResourceManager.getColor(255, 255, 255));
		itemDetails.setBounds(404, 130, 364, 37);
		itemDetails.setEditable(false);
		
		orderSubtotal = new Text(shlNileDotCom, SWT.NONE);
		orderSubtotal.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		orderSubtotal.setBackground(SWTResourceManager.getColor(255, 255, 255));
		orderSubtotal.setBounds(404, 173, 364, 37);
		orderSubtotal.setEditable(false);
		
		Label lblEnterItemId = new Label(shlNileDotCom, SWT.NONE);
		lblEnterItemId.setBackground(SWTResourceManager.getColor(SWT.COLOR_TRANSPARENT));
		lblEnterItemId.setForeground(SWTResourceManager.getColor(SWT.COLOR_YELLOW));
		lblEnterItemId.setBounds(160, 50, 213, 25);
		lblEnterItemId.setText("Enter item ID for Item #1:");
		
		Label lblEnterQuantityFor = new Label(shlNileDotCom, SWT.NONE);
		lblEnterQuantityFor.setBackground(SWTResourceManager.getColor(SWT.COLOR_TRANSPARENT));
		lblEnterQuantityFor.setForeground(SWTResourceManager.getColor(SWT.COLOR_YELLOW));
		lblEnterQuantityFor.setText("Enter quantity for Item #1:");
		lblEnterQuantityFor.setBounds(153, 95, 213, 25);
		
		Label lblDetailsForItem = new Label(shlNileDotCom, SWT.NONE);
		lblDetailsForItem.setBackground(SWTResourceManager.getColor(SWT.COLOR_TRANSPARENT));
		lblDetailsForItem.setForeground(SWTResourceManager.getColor(SWT.COLOR_YELLOW));
		lblDetailsForItem.setText("Details for Item #1:");
		lblDetailsForItem.setBounds(210, 138, 164, 25);
		
		Label lblOrderSubtotalFor = new Label(shlNileDotCom, SWT.NONE);
		lblOrderSubtotalFor.setBackground(SWTResourceManager.getColor(SWT.COLOR_TRANSPARENT));
		lblOrderSubtotalFor.setForeground(SWTResourceManager.getColor(SWT.COLOR_YELLOW));
		lblOrderSubtotalFor.setText("Order subtotal for 0 item(s):");
		lblOrderSubtotalFor.setBounds(145, 179, 221, 25);
		
		Canvas canvas = new Canvas(shlNileDotCom, SWT.NONE);
		canvas.setBackground(SWTResourceManager.getColor(0, 255, 255));
		canvas.setBounds(0, 227, 837, 161);
		
		Button btnFindItem = new Button(canvas, SWT.NONE);
		btnFindItem.setBounds(37, 10, 277, 35);
		btnFindItem.setText("Find Item #1");
		
		Button btnViewCurrentOrder = new Button(canvas, SWT.NONE);
		btnViewCurrentOrder.setText("View Current Order");
		btnViewCurrentOrder.setBounds(37, 51, 277, 35);
		
		Button btnStartNewOrder = new Button(canvas, SWT.NONE);
		btnStartNewOrder.setText("Start New Order");
		btnStartNewOrder.setBounds(37, 96, 277, 35);
		
		Button btnExitcloseApp = new Button(canvas, SWT.NONE);
		btnExitcloseApp.setText("Exit (Close app)");
		btnExitcloseApp.setBounds(448, 96, 277, 35);
		
		Button btnCompleteOrder = new Button(canvas, SWT.NONE);
		btnCompleteOrder.setText("Complete Order - Check Out");
		btnCompleteOrder.setBounds(448, 51, 277, 35);
		
		Button btnPurchaseItem = new Button(canvas, SWT.NONE);
		btnPurchaseItem.setText("Purchase Item #1");
		btnPurchaseItem.setBounds(448, 10, 277, 35);
		
		btnFindItem.setEnabled(true);
		btnPurchaseItem.setEnabled(false);
		btnViewCurrentOrder.setEnabled(false);
		btnCompleteOrder.setEnabled(false);
		btnStartNewOrder.setEnabled(true);
		btnExitcloseApp.setEnabled(true);
		
		btnFindItem.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				try	{
					File inventory = new File("C:\\Users\\gabri\\eclipse-files\\inventory.txt");
					file_reader = new Scanner(inventory);
					double original_price = 0;
					double real_total = 0;
					int itemFoundFlag = 0;
					ArrayList <String> iSelection = new ArrayList<String>();
					
					while(file_reader.hasNextLine())
					{
						String[] id_line = file_reader.nextLine().split(", ");
						
						if(id_line[0].equals(itemID.getText()))
						{
							if(Boolean.parseBoolean(id_line[2]) == false)
							{
								itemFoundFlag = -1;
								break;
							}
							for(int i = 0; i < id_line.length; i++)
							{
								iSelection.add(id_line[i]);
							}
							iSelection.remove(2);
							iSelection.add(itemQuantity.getText());
							
							if(Integer.parseInt(iSelection.get(3)) < 5)
							{
								iSelection.add("0%");
							}
							else if(Integer.parseInt(iSelection.get(3)) < 10)
							{
								iSelection.add("10%");
							}
							else if(Integer.parseInt(iSelection.get(3)) < 15)
							{
								iSelection.add("15%");
							}
							else
							{
								iSelection.add("20%");
							}
							original_price = Double.parseDouble(iSelection.get(2)) * Double.parseDouble(iSelection.get(3));
							
							real_total = (original_price - 
									(original_price * 
									(Double.parseDouble(iSelection.get(4).substring(0, iSelection.get(4).length() - 1)) / 100)));
							iSelection.add("" + real_total);
							
							itemFoundFlag = 1;
							user_orders.add(iSelection);
							
							itemDetails.setText("");
							for(String obj : iSelection)
							{
								System.out.println(obj);
								itemDetails.setText(itemDetails.getText() + obj + " ");
							}
							btnFindItem.setEnabled(false);
							btnPurchaseItem.setEnabled(true);
							//itemDetails.setText();
							break;
						}
					}
					
					if(itemFoundFlag != 1)
					{
						String error_msg = "";
						
						if(itemFoundFlag == -1)
						{
							error_msg = "Sorry...that item is out of stock, please try another item.";
							itemID.setText("");
							itemQuantity.setText("");
						}
						else
						{
							error_msg = "Item ID " + itemID.getText() + " not in file";
						}
						
						Shell warning_window = new Shell();
						warning_window.setText("Nile Dot Com - Error");
						warning_window.setSize(625, 250);
						
						Label warning_msg = new Label(warning_window, SWT.NONE);
						warning_msg.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
						warning_msg.setBounds(50, 65, 500, 50);
						
						warning_msg.setText(error_msg);
						
						Button exit_btn = new Button(warning_window, SWT.PUSH);
						exit_btn.setBounds(480, 140, 100, 50);
						exit_btn.setBackground(SWTResourceManager.getColor(SWT.COLOR_BLUE));
						exit_btn.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
						
						exit_btn.setText("OK");
						
						exit_btn.addSelectionListener(new SelectionAdapter() {
							@Override
							public void widgetSelected(SelectionEvent e) {
								warning_window.dispose();
							}
						});
						
						warning_window.setVisible(true);
						itemFoundFlag = 0;
						
					}
				}
				catch(Exception file_excpt){
					file_excpt.printStackTrace();
				}
				finally {
					file_reader.close();
				}
			}
		});
		
		btnPurchaseItem.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				double totalCost = 0;
				
				order_count++;
				btnFindItem.setText("Find Item #" + (order_count + 1));
				btnPurchaseItem.setText("Purchase Item #" + (order_count + 1));
				btnFindItem.setEnabled(true);
				btnViewCurrentOrder.setEnabled(true);
				btnCompleteOrder.setEnabled(true);
				btnStartNewOrder.setEnabled(true);
				btnPurchaseItem.setEnabled(false);
				
				itemID.setText("");
				itemQuantity.setText("");
				
				lblEnterItemId.setText("Enter item ID for Item #" + (order_count + 1) + ":");
				lblEnterQuantityFor.setText("Enter quantity for Item #" + (order_count + 1) + ":");
				lblDetailsForItem.setText("Details for Item #" + (order_count) + ":");
				lblOrderSubtotalFor.setText("Order subtotal for " + (order_count) + " item(s):");
				
				for(ArrayList<String> obj : user_orders)
				{
					totalCost = ((100 * totalCost) + (100 * Double.parseDouble(obj.get(5)))) / 100;
				}
				orderSubtotal.setText("$" + df.format(totalCost));
				
				try {
					Shell purchase_window = new Shell();
					purchase_window.setText("Nile Dot Com - Item Confirmed");
					purchase_window.setSize(625, 250);
					
					Label purchase_msg = new Label(purchase_window, SWT.NONE);
					purchase_msg.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
					purchase_msg.setBounds(50, 65, 500, 50);
					
					purchase_msg.setText("Item #" + order_count + " accepted. Added to your cart.");
					
					Button exit_btn = new Button(purchase_window, SWT.PUSH);
					exit_btn.setBounds(480, 140, 100, 50);
					exit_btn.setBackground(SWTResourceManager.getColor(SWT.COLOR_BLUE));
					exit_btn.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
					
					exit_btn.setText("OK");
					
					exit_btn.addSelectionListener(new SelectionAdapter() {
						@Override
						public void widgetSelected(SelectionEvent e) {
							purchase_window.dispose();
						}
					});
					
					purchase_window.setVisible(true);
				}
				catch(Exception p)
				{
					p.printStackTrace();
				}
			}
		});
		
		btnViewCurrentOrder.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				ord_list = "";
				int heightSize = 0;
				Shell curr_orders = new Shell();
				curr_orders.setText("Nile Dot Com");
				curr_orders.setSize(1000, 250);
				
				Label order_display = new Label(curr_orders, SWT.NONE);
				order_display.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
				
				
				for(int i = 0; i < user_orders.size(); i++)
				{
					ord_list += (i + 1) + ". ";
					for(int j = 0; j < user_orders.get(i).size(); j++)
					{
						ord_list += user_orders.get(i).get(j) + " ";
					}
					ord_list += "\n";
					heightSize += 35;
				}
				order_display.setText(ord_list);
				order_display.setBounds(50, 35, 700, heightSize);
				
				Button exit_btn = new Button(curr_orders, SWT.PUSH);
				exit_btn.setBounds(570, 140, 100, 50);
				exit_btn.setBackground(SWTResourceManager.getColor(SWT.COLOR_BLUE));
				exit_btn.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
				
				exit_btn.setText("OK");
				
				exit_btn.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
						curr_orders.dispose();
					}
				});
				
				curr_orders.setVisible(true);
			}
		});
		
		btnStartNewOrder.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				user_orders.clear();
				
				if(orderCompleted == true)
				{
					orderCompleted = false;
					shlNileDotCom.dispose();
				}
				else
				{
					itemID.setText("");
					itemQuantity.setText("");
					itemDetails.setText("");
					orderSubtotal.setText("");
					btnViewCurrentOrder.setEnabled(false);
					btnPurchaseItem.setEnabled(false);
					btnCompleteOrder.setEnabled(false);
					btnFindItem.setEnabled(true);
				}
			}
		});
		
		btnCompleteOrder.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				//FIXME: SAVE ORDERS TO TRANSACTIONS.TXT
				//		 PROVIDE UNIQUE TRANSACTION IDS BASED ON CURRENT DATE/TIME
				try
				{
					FileWriter transc_file = new FileWriter("C:\\Users\\gabri\\eclipse-files\\transactions.txt");
					SimpleDateFormat invoiceForm = new SimpleDateFormat("M/dd/yy',' HH:mm:ss z");
					SimpleDateFormat idForm = new SimpleDateFormat("ddMMyyHHmm");
					Date curr_date = new Date(System.currentTimeMillis());
					ord_list = "";
					
					String date = "";
					int numLines = 0;
					String order_format = "\t\tItem# / ID / Title / Price / Qty / Disc % / Subtotal:";
					double tax = 0.06;
					double num_subTotal = Double.parseDouble(orderSubtotal.getText().substring(1));
					double taxAmount = num_subTotal * tax;
					
					for(int i = 0; i < user_orders.size(); i++)
					{
						ord_list += "\t\t" + (i + 1) + ". ";
						for(int j = 0; j < user_orders.get(i).size(); j++)
						{
							ord_list += user_orders.get(i).get(j) + " ";
						}
						ord_list += "\n";
					}
					
					Shell checkout = new Shell();
					checkout.setText("Nile Dot Com - FINAL INVOICE");
					checkout.setSize(1000, 750);
					
					Label summary = new Label(checkout, SWT.NONE);
					summary.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
					
					summary.setBounds(50, 35, 700, 800);
					
					date = "\t\tDate: " + invoiceForm.format(curr_date);
					numLines = user_orders.size();
					//ord_list
					//Integer.parseInt(orderSubtotal.getText())
					
					summary.setText(date + "\n\n" +
									"\t\tNumber of line items: " + numLines + "\n\n" +
									order_format + "\n\n" +
									ord_list + "\n" +
									"\t\tOrder Subtotal:\t$" + num_subTotal + "\n\n" +
									"\t\tTax rate:\t\t" + (tax * 100) + "%\n\n" +
									"\t\tTax amount:\t$" + df.format((taxAmount)) + "\n\n" +
									"\t\tORDER TOTAL:\t$" + df.format(num_subTotal + taxAmount) + "\n\n" +
									"\t\tThanks for shopping at Nile Dot Com!");
					
					Button exit_btn = new Button(checkout, SWT.PUSH);
					exit_btn.setBounds(875, 640, 100, 50);
					exit_btn.setBackground(SWTResourceManager.getColor(SWT.COLOR_BLUE));
					exit_btn.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
					exit_btn.setText("OK");
					
					checkout.setVisible(true);
					
					exit_btn.addSelectionListener(new SelectionAdapter() {
						@Override
						public void widgetSelected(SelectionEvent e) {
							btnFindItem.setEnabled(false);
							btnPurchaseItem.setEnabled(false);
							btnCompleteOrder.setEnabled(false);
							checkout.dispose();
							orderCompleted = true;
						}
					});
					
					
					for(ArrayList<String> obj1 : user_orders)
					{
						transc_file.write("" + idForm.format(curr_date) + ", ");
						for(String obj2 : obj1)
						{
							transc_file.write(obj2 + ", ");
						}
						transc_file.write(invoiceForm.format(curr_date) + "\n");
					}
					transc_file.close();
				}
				catch(Exception file3_excpt)
				{
					file3_excpt.printStackTrace();
				}
			}
		});
		
		btnExitcloseApp.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shlNileDotCom.dispose();
			}
		});
		
	}
}
